// import './App.css'

import { BrowserRouter, Route, Routes } from "react-router-dom"
import SignUp from "./components/SignUp"
import Login from "./components/Login"
import LandingPage from "./components/LandingPage"
import Profile from "./components/Profile"
import AddProduct from "./components/AddProduct"
import ProductDetails from "./components/ProductDetails"
import UpdateProduct from "./components/UpdateProduct"

function App() {

  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="signup" element={<SignUp />} />
          {/* <Route path="profile/:userId" element={<Profile />} /> */}
          <Route path="profile" element={<Profile />} />
          <Route path="addProduct" element={<AddProduct />} />
          <Route path="productDetails/:productId" element={<ProductDetails />} />
          <Route path="updateProduct/:productId" element={<UpdateProduct />} />
          <Route path="login" element={<Login />} />
          {/* <Route path="*" element={<Login />} /> */}
        </Routes>
      </BrowserRouter>
    </>
  )
}

export default App
