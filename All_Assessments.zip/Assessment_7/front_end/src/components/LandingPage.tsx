export default function LandingPage(){
    return(
        <>
             <a href="/signup">Register as Retailer</a> 
             <a href="*">Register as Retailer</a> 
        </>
    )
}