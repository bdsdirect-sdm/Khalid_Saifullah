/* eslint-disable @typescript-eslint/no-explicit-any */
import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { jwtDecode } from 'jwt-decode';
import { Formik, Form, Field } from 'formik';
import * as Yup from 'yup';

interface Product {
  id: number;
  name: string;
  price: number;
  category: string;
  quantity: number;
  status: string;
  image?: string; 
}

const ProductSchema = Yup.object().shape({
  name: Yup.string()
    .max(50, 'Product name must be at most 50 characters')
    .required('Product name is required'),
  price: Yup.number()
    .positive('Price must be a positive number')
    .required('Price is required'),
  category: Yup.string()
    .max(30, 'Category must be at most 30 characters')
    .required('Category is required'),
  quantity: Yup.number()
    .integer('Quantity must be an integer')
    .positive('Quantity must be a positive number')
    .required('Quantity is required'),
  status: Yup.string()
    .required('Status is required'),
  image: Yup.mixed().nullable(),
});

export default function UpdateProduct() {
  const { productId } = useParams<{ productId: string }>();
  const navigate = useNavigate();
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const token: any = localStorage.getItem('token');
    if (!token) {
      setError('Unauthorized access');
      setLoading(false);
      return;
    }

    const decoded: any = jwtDecode(token);
    const retailerId = decoded.id;

    const fetchProductDetails = async () => {
      try {
        const response = await axios.get(`http://localhost:3000/product-details/${retailerId}/${productId}`);
        setProduct(response.data.product);
      } catch (err: any) {
        if (err.response) {
          setError(err.response.data.message || 'Failed to fetch product details');
        } else {
          setError('Server error');
        }
      } finally {
        setLoading(false);
      }
    };

    fetchProductDetails();
  }, [productId]);

  const handleSubmit = async (values: any) => {
    try {
      const token: any = localStorage.getItem('token');
      const decoded: any = jwtDecode(token);
      const retailerId = decoded.id;

      const formData = new FormData();
      formData.append('name', values.name);
      formData.append('price', values.price.toString());
      formData.append('category', values.category);
      formData.append('quantity', values.quantity.toString());
      formData.append('status', values.status);
      if (values.image) {
        formData.append('image', values.image);
      }

      await axios.put(`http://localhost:3000/update-product/${retailerId}/${productId}`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      alert('Product updated successfully!');
      navigate(`/productDetails/${productId}`); // Redirect to the product details page
    } catch (error: any) {
      console.error(error);
      alert('Failed to update product. Please try again.');
    }
  };

  if (loading) {
    return <div>Loading product details...</div>;
  }

  if (error) {
    return <div className="text-danger">{error}</div>;
  }

  if (!product) {
    return <div>Product not found.</div>;
  }

  return (
    <div className="container">
      <h2>Update Product</h2>
      <Formik
        initialValues={{
          name: product.name,
          price: product.price,
          category: product.category,
          quantity: product.quantity,
          status: product.status,
          image: null, // For file upload
        }}
        validationSchema={ProductSchema}
        onSubmit={handleSubmit}
      >
        {({ setFieldValue, errors, touched }) => (
          <Form>
            <div className="form-group">
              <label htmlFor="name">Product Name</label>
              <Field
                type="text"
                className="form-control"
                name="name"
                id="name"
                placeholder="Enter product name"
              />
              {errors.name && touched.name && <div className="text-danger">{errors.name}</div>}
            </div>
            <div className="form-group">
              <label htmlFor="price">Price</label>
              <Field
                type="number"
                className="form-control"
                name="price"
                id="price"
                placeholder="Enter product price"
              />
              {errors.price && touched.price && <div className="text-danger">{errors.price}</div>}
            </div>
            <div className="form-group">
              <label htmlFor="category">Category</label>
              <Field
                type="text"
                className="form-control"
                name="category"
                id="category"
                placeholder="Enter product category"
              />
              {errors.category && touched.category && <div className="text-danger">{errors.category}</div>}
            </div>
            <div className="form-group">
              <label htmlFor="quantity">Quantity</label>
              <Field
                type="number"
                className="form-control"
                name="quantity"
                id="quantity"
                placeholder="Enter product quantity"
              />
              {errors.quantity && touched.quantity && <div className="text-danger">{errors.quantity}</div>}
            </div>
            <div className="form-group">
              <label htmlFor="status">Status</label>
              <Field as="select" name="status" className="form-control">
              <option value="Draft">Draft</option>
              <option value="Published">Published</option>
              </Field>
              {errors.status && touched.status && <div className="text-danger">{errors.status}</div>}
            </div>
            <div className="mb-3">
              <label htmlFor="image" className="form-label">
                Upload New Product Image (optional)
              </label>
              <input
                className="form-control"
                type="file"
                id="image"
                name="image"
                onChange={(event) => {
                  const file = event.currentTarget.files![0];
                  setFieldValue('image', file);
                }}
              />
              {errors.image && touched.image && <div className="text-danger">{errors.image}</div>}
            </div>
            <button type="submit" className="btn btn-primary">
              Update Product
            </button>
          </Form>
        )}
      </Formik>
    </div>
  );
}
