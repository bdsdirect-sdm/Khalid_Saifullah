/* eslint-disable @typescript-eslint/no-explicit-any */
import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import { jwtDecode } from 'jwt-decode';
import '../productDetails.css'

interface Product {
  id: number;
  name: string;
  price: number;
  category: string;
  quantity: number;
  status: string;
  image?: string; 
}

export default function ProductDetails() {
  const { productId } = useParams<{ productId: string }>();
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const token: any = localStorage.getItem('token');
    if (!token) {
      setError('Unauthorized access');
      setLoading(false);
      return;
    }

    const decoded: any = jwtDecode(token);
    const retailerId = decoded.id;

    const fetchProductDetails = async () => {
      try {
        const response = await axios.get(`http://localhost:3000/product-details/${retailerId}/${productId}`);
        setProduct(response.data.product);
      } catch (err: any) {
        if (err.response) {
          setError(err.response.data.message || 'Failed to fetch product details');
        } else {
          setError('Server error');
        }
      } finally {
        setLoading(false);
      }
    };

    fetchProductDetails();
  }, [productId]);

  if (loading) {
    return <div>Loading product details...</div>;
  }

  if (error) {
    return <div className="text-danger">{error}</div>;
  }

  if (!product) {
    return <div>Product not found.</div>;
  }

  return (
    <div className="container">
      <h2>Product Details</h2>
      <div className="card">
        <img src={"http://localhost:3000/"+product.image} alt={product.name} className="card-img-top productImg" />
        <div className="card-body">
          <h5 className="card-title">{product.name}</h5>
          <p className="card-text">Price: ${product.price}</p>
          <p className="card-text">Category: {product.category}</p>
          <p className="card-text">Quantity: {product.quantity}</p>
          <p className="card-text">Status: {product.status}</p>
        </div>
      </div>
      <a className='btn btn-primary' href='/profile'>Back to profile</a>
    </div>
  );
}
