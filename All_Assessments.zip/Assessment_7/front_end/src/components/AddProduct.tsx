/* eslint-disable @typescript-eslint/no-explicit-any */
import { Link, useNavigate } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { Formik, Form, Field } from 'formik';
import * as Yup from 'yup';
import axios from 'axios';
import { jwtDecode } from 'jwt-decode';

interface FormData {
  name: string;
  price: number;
  category: string;
  quantity: number;
  status: string;
  image?: File;
}

const ProductSchema = Yup.object().shape({
  name: Yup.string()
    .max(50, 'Product name must be at most 50 characters')
    .required('Product name is required'),
  price: Yup.number()
    .positive('Price must be a positive number')
    .required('Price is required'),
  category: Yup.string()
    .max(30, 'Category must be at most 30 characters')
    .required('Category is required'),
  quantity: Yup.number()
    .integer('Quantity must be an integer')
    .positive('Quantity must be a positive number')
    .required('Quantity is required'),
  status: Yup.string()
    .required('Status is required'),
  image: Yup.mixed()
    .required('Product image is required')
    .test(
      'fileFormat',
      'Unsupported Format, only JPG and PNG allowed',
      (value) => {
        if (value && value instanceof File) {
          return value.type === 'image/jpeg' || value.type === 'image/png';
        }
        return false;
      }
    ),
});

export default function AddProduct() {
  const navigate = useNavigate();

  const handleSubmit = async (values: FormData) => {
    try {
      const token: any = localStorage.getItem('token');
      const decoded: any = jwtDecode(token);
      const retailerId = decoded.id;

      const formData = new FormData();
      formData.append('name', values.name);
      formData.append('price', values.price.toString());
      formData.append('category', values.category);
      formData.append('quantity', values.quantity.toString());
      formData.append('status', values.status);
      if (values.image) {
        formData.append('image', values.image);
      }

      await axios.post(
        `http://localhost:3000/add-product/${retailerId}`,
        formData,
        {
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        }
      );

      alert('Product added successfully!');
      navigate('/profile');
    } catch (error: any) {
      console.error(error);
      if (error.response && error.response.status === 409) {
        toast.error(error.response.data.message);
      } else {
        toast.error('Failed to add product. Please try again.');
      }
    }
  };

  return (
    <div className="container">
      <h2>Add New Product</h2>
      <ToastContainer />
      <Formik
        initialValues={{
          name: '',
          price: 0,
          category: '',
          quantity: 0,
          status: '',
          image: undefined,
        }}
        validationSchema={ProductSchema}
        onSubmit={handleSubmit}
      >
        {({ setFieldValue, errors, touched }) => (
          <Form>
            <div className="form-group">
              <label htmlFor="name">Product Name</label>
              <Field
                type="text"
                className="form-control"
                name="name"
                id="name"
                placeholder="Enter product name"
              />
              {errors.name && touched.name && (
                <div className="text-danger">{errors.name}</div>
              )}
            </div>
            <div className="form-group">
              <label htmlFor="price">Price</label>
              <Field
                type="number"
                className="form-control"
                name="price"
                id="price"
                placeholder="Enter product price"
              />
              {errors.price && touched.price && (
                <div className="text-danger">{errors.price}</div>
              )}
            </div>
            <div className="form-group">
              <label htmlFor="category">Category</label>
              <Field
                type="text"
                className="form-control"
                name="category"
                id="category"
                placeholder="Enter product category"
              />
              {errors.category && touched.category && (
                <div className="text-danger">{errors.category}</div>
              )}
            </div>
            <div className="form-group">
              <label htmlFor="quantity">Quantity</label>
              <Field
                type="number"
                className="form-control"
                name="quantity"
                id="quantity"
                placeholder="Enter product quantity"
              />
              {errors.quantity && touched.quantity && (
                <div className="text-danger">{errors.quantity}</div>
              )}
            </div>
            <div className="form-group">
              <label htmlFor="status">Status</label>
              <Field as="select" name="status" className="form-control">
                <option value="Draft">Draft</option>
                <option value="Published">Published</option>
              </Field>
              {errors.status && touched.status && (
                <div className="text-danger">{errors.status}</div>
              )}
            </div>
            <div className="mb-3">
              <label htmlFor="image" className="form-label">
                Upload Product Image (JPG, PNG)
              </label>
              <input
                className="form-control"
                type="file"
                id="image"
                name="image"
                onChange={(event) => {
                  const file = event.currentTarget.files![0];
                  setFieldValue('image', file);
                }}
              />
              {errors.image && touched.image && (
                <div className="text-danger">{errors.image}</div>
              )}
            </div>
            <button type="submit" className="btn btn-primary">
              Add Product
            </button>
          </Form>
        )}
      </Formik>
      <p>
        Go back to <Link to="/profile">Profile</Link>
      </p>
    </div>
  );
}
