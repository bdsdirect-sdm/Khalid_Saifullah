import { Link, useNavigate } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { Formik, Form, Field } from 'formik';
import * as Yup from 'yup';
import axios from 'axios';

interface FormData {
  firstname: string;
  lastname: string;
  email: string;
  profile_img?: File;
  companyLogo?: File;
  address: string;
  companyName: string;
  phone_no: string;

}

const SignupSchema = Yup.object().shape({
  firstname: Yup.string()
    .matches(/^[A-Za-z]+$/, 'First name must contain only letters')
    .max(20, 'First name must be at most 20 characters')
    .required('First name is required'),
  lastname: Yup.string()
    .matches(/^[A-Za-z]+$/, 'Last name must contain only letters')
    .max(20, 'Last name must be at most 20 characters')
    .required('Last name is required'),
  companyName: Yup.string()
    .matches(/^[A-Za-z]+$/, 'Company name must contain only letters')
    .max(20, 'Last name must be at most 20 characters')
    .required('Company name is required'),
  email: Yup.string().email('Invalid email').required('Email is required'),
  address: Yup.string().required('address is required'),
  phone_no: Yup.string()
    .matches(/^[0-9]+$/, 'Contact number must be numeric')
    .length(10, 'Contact number must be exactly 10 digits')
    .required('Contact number is required'),
  profile_img: Yup.mixed()
    .required('Profile image is required')
    .test(
      'fileFormat',
      'Unsupported Format, only JPG and PNG allowed',
      (value) => {
        if (value && value instanceof File) {
          return value.type === 'image/jpeg' || value.type === 'image/png';
        }
        return false;
      }
    ),
    companyLogo: Yup.mixed()
    .required('Company Logo is required')
    .test(
      'fileFormat',
      'Unsupported Format, only JPG and PNG allowed',
      (value) => {
        if (value && value instanceof File) {
          return value.type === 'image/jpeg' || value.type === 'image/png';
        }
        return false;
      }
    ),
});

export default function SignUp() {
  const navigate = useNavigate();

  const handleSubmit = async (values: FormData) => {
    try {
      const formData = new FormData();
   
      formData.append('firstname', values.firstname);
      formData.append('lastname', values.lastname);
      formData.append('email', values.email);
      formData.append('address', values.address);
      formData.append('companyName', values.companyName);
      formData.append('phone_no', values.phone_no);
      if (values.profile_img) {
        formData.append('profile_img', values.profile_img);
      }
      if (values.companyLogo) {
        formData.append('companyLogo', values.companyLogo);
      }
       await axios.post(
        'http://localhost:3000/signup',
        formData,
        {
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        }
      );
      alert('Registration successful!');
      navigate('/login');
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
    } catch (error: any) {
      console.error(error);
      if (error.response && error.response.status === 409) {
        toast.error(error.response.data.message);
      } else {
        toast.error('Registration failed. Please try again.');
      }
    }
  };

  return (
    <div className="container">
      <h2>Please Signup</h2>
      <ToastContainer />
      <Formik
        initialValues={{
          firstname: '',
          lastname: '',
          email: '',
          address: '',
          companyName: '',
          phone_no: '',
          profile_img: undefined, // Initialize img as undefined
          companyLogo: undefined,
        }}
        validationSchema={SignupSchema}
        onSubmit={handleSubmit}
      >
        {({ setFieldValue, errors, touched }) => (
          <Form>
            <div className="form-row">
              <div className="form-group col-md-6">
                <label htmlFor="firstname">First Name</label>
                <Field
                  type="text"
                  className="form-control"
                  name="firstname"
                  id="firstname"
                  placeholder="First Name"
                />
                {errors.firstname && touched.firstname && (
                  <div className="text-danger">{errors.firstname}</div>
                )}
              </div>
              <div className="form-group col-md-6">
                <label htmlFor="lastname">Last Name</label>
                <Field
                  type="text"
                  className="form-control"
                  name="lastname"
                  id="lastname"
                  placeholder="Last Name"
                />
                {errors.lastname && touched.lastname && (
                  <div className="text-danger">{errors.lastname}</div>
                )}
              </div>
            </div>
            <div className="form-group">
              <label htmlFor="email">Email</label>
              <Field
                type="email"
                className="form-control"
                name="email"
                id="email"
                placeholder="Email"
              />
              {errors.email && touched.email && (
                <div className="text-danger">{errors.email}</div>
              )}
            </div>
            
            <div className="form-group">
              <label htmlFor="address">Address</label>
              <Field
                type="text"
                className="form-control"
                name="address"
                id="address"
                placeholder="Enter your address"
              />
              {errors.address && touched.address && (
                <div className="text-danger">{errors.address}</div>
              )}
            </div>
            <div className="form-group">
              <label htmlFor="companyName">Enter Company Name</label>
              <Field
                type="text"
                className="form-control"
                name="companyName"
                id="companyName"
                placeholder="Enter Company Name"
              />
              {errors.companyName && touched.companyName && (
                <div className="text-danger">{errors.companyName}</div>
              )}
            </div>
            <div className="form-group">
              <label htmlFor="phone_no">Enter Phone Number</label>
              <Field
                type="text"
                className="form-control"
                name="phone_no"
                id="phone_no"
                placeholder="Enter phone Number"
              />
              {errors.phone_no && touched.phone_no && (
                <div className="text-danger">{errors.phone_no}</div>
              )}
            </div>
            <div className="mb-3">
              <label htmlFor="img" className="form-label">
                Upload Profile Image (JPG, PNG)
              </label>
              <input
                className="form-control"
                type="file"
                id="profile_img"
                name="profile_img"
                onChange={(event) => {
                  const file = event.currentTarget.files![0];
                  setFieldValue('profile_img', file);
                }}
              />
              {errors.profile_img && touched.profile_img && (
                <div className="text-danger">{errors.profile_img}</div>
              )}
            </div>
            <div className="mb-3">
              <label htmlFor="companyLogo" className="form-label">
                Upload Company Logo
              </label>
              <input
                className="form-control"
                type="file"
                id="companyLogo"
                name="companyLogo"
                onChange={(event) => {
                  const file = event.currentTarget.files![0];
                  setFieldValue('companyLogo', file);
                }}
              />
              {errors.companyLogo && touched.companyLogo && (
                <div className="text-danger">{errors.companyLogo}</div>
              )}
            </div>
            <button type="submit" className="btn btn-primary">
              Signup
            </button>
          </Form>
        )}
      </Formik>
      <p>
        Already have an account? <Link to="/login">Login</Link>
      </p>
    </div>
  );
}