import express, { NextFunction, Request, Response } from 'express';
import sequelize from './src/config/database';
import Retailer from './src/models/Retailer';
import Product from './src/models/Product';
const CORS = require('cors');
const bcrypt = require('bcrypt');
var jwt = require('jsonwebtoken');
import dotenv from 'dotenv';
import userRoutes from './src/routes/userRoutes'
import path from 'path';

dotenv.config();

const app = express();
app.use(express.json());

app.use(CORS({
    origin: true,
    optionsSuccessStatus: 200 
}));

app.use( express.static(path.join(__dirname,'uploads')))
app.use("/uploads", express.static(path.join(__dirname,'uploads')))


app.use('/', userRoutes);


const startServer = async () => {
    try {
        await sequelize.authenticate();
        console.log('Database connected.');

        await Retailer.sync({ force: false });
        await Product.sync({ force: false });

        app.listen(3000, () => {
            console.log('Server is running http://localhost:3000');
        });
    } catch (error: any) {
        console.error('Unable to connect to the database:', error);
    }
};

startServer();