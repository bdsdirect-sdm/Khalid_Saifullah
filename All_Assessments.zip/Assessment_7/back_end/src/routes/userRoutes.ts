import { Router } from 'express';
// import { getAgencies, addUser, loginUser, check, userDetails, updateApprovalStatus } from '../controller/userController';
import { addProduct, addRetailer, check, deleteProduct, getProductDetails, getRetailerProducts, getRetailerWithProducts, loginUser, updateProduct } from '../controller/userController';
// import {validateUser} from '../middleware/validateUser'
import { upload } from '../middleware/upload';
// import { authorizeUser } from '../middleware/authorizeUser';

const router = Router();

router.get('/', check);
// router.get('/agencies', getAgencies);

router.post('/signup', upload.fields([{name:"profile_img"},{name:"companyLogo"}]),addRetailer);
router.get('/retailer-details/:retailerId', getRetailerWithProducts);
router.post('/add-product/:retailerId', upload.single('image'), addProduct);
router.get('/retailer-products/:retailerId', getRetailerProducts);
router.get('/product-details/:retailerId/:productId', getProductDetails);
router.put('/update-product/:retailerId/:productId', upload.single('image'), updateProduct);
router.delete('/delete-product/:retailerId/:productId', deleteProduct);
router.post('/login',loginUser)


// router.post('/signup', upload.fields([{name:"profileImg"},{name:"resume"}]), validateUser,addUser);
// router.get('/userDetails/:userId',authorizeUser, userDetails)



export default router;
