import { Model, DataTypes } from 'sequelize';
import sequelize from '../config/database';
import Retailer from './Retailer'; 

class Product extends Model {
  public id!: number;
  public name!: string;
  public category!: string;
  public price!: number;
  public quantity!: number;
  public image!: string;
  public status!: string;
  public retailerId!: number; 
}

Product.init({
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false
  },
  category: {
    type: DataTypes.STRING,
    allowNull: false
  },
  price: {
    type: DataTypes.FLOAT,
    allowNull: false
  },
  quantity: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  image: {
    type: DataTypes.STRING,
    allowNull: false
  },
  status: {
    type: DataTypes.ENUM('Draft','Published'),
    allowNull: false
  },
  retailerId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: Retailer, 
      key: 'id'
    },
    onDelete: 'CASCADE'  
  }
}, {
  sequelize,
  modelName: 'Product',
  tableName: 'products',
  timestamps: true,
  paranoid: true
});

Retailer.hasMany(Product, { foreignKey: 'retailerId', as: 'products'});
Product.belongsTo(Retailer, { foreignKey: 'retailerId' });

export default Product;
