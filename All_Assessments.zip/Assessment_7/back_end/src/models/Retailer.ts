import { Model, DataTypes } from 'sequelize';
import sequelize from '../config/database'; 
import Product from './Product';

class Retailer extends Model {
  public id!: number;
  public firstname!: string;
  public lastname!: string;
  public email!: string;
  public phone_no!: string;
  public address!: string;
  public profile_img!: string;
  public companyLogo!: string;
  public password!: string;
  public companyName!: string;
}

Retailer.init({
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true
  },
  firstname: {
    type: DataTypes.STRING,
    allowNull: false
  },
  lastname: {
    type: DataTypes.STRING,
    allowNull: false
  },
  companyName: {
    type: DataTypes.STRING,
    allowNull: true
  },
  email: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true
  },
  phone_no: {
    type: DataTypes.STRING,
    allowNull: false
  },
  address: {
    type: DataTypes.STRING,
    allowNull: true
  },
  profile_img: {
    type: DataTypes.STRING,
    allowNull: true
  },
  companyLogo: {
    type: DataTypes.STRING,
    allowNull: true
  },
  password: {
    type: DataTypes.STRING,
    allowNull: false
  }
}, {
  sequelize,
  modelName: 'Retailer',
  tableName: 'retailers',
  timestamps: true
});



export default Retailer;
