import { profile } from "console"
import Joi from "joi"
// import { httpStatusCodes } from "../../constants"
export const validateUser =(req:any,res:any,next:any)=>{
    const validateUserSchema=Joi.object({
        firstName:Joi.string().required(),
        lastName:Joi.string().required(),
        email:Joi.string().email().required(),
        address:Joi.string().required(),
        contact:Joi.string().required().max(10).min(10),
        profile_img:Joi.string(),
        
    })
    const {firstName, lastName, email, contact,address, profile_img} = req.body
    // const {error}=validateUserSchema.validate(req.body)
    const {error}=validateUserSchema.validate({firstName, lastName, email, contact, address, profile_img})
    if(error){
        const msg = error.details.map(el=>el.message).join(',')
        // console.log(msg)
        return res.status(409).json({message:msg})
    }
    next()
}
