/* eslint-disable @typescript-eslint/no-explicit-any */
import axios from "axios"
import { useQuery } from "@tanstack/react-query"
import { useState } from "react"

const fetchUserDetails =(pageId:any)=>{
    return axios.get(`http://localhost:3000/users/?_limit=8&_page=${pageId}`)
}

export default function UserList(){

    const [page, setPage] = useState(1)

    const {data, isLoading, isError, error, isFetching} = useQuery({
    queryKey:["users", page],
    queryFn:()=> fetchUserDetails(page)
    }) 

    if(isLoading){
        return<div>Page is Loading</div>
    }

    if(isError){
        return<div>{error.message}</div>
    }

    // console.log("data...................",data)
    console.log("loading...", isLoading)
    console.log("Fetching.......", isFetching)
    // const {firstName, lastName,address,email} = data?.data || {}
  
    return(
        <>
        <h1>Profile page</h1>
        <div>
            {data?.data.data.map((item:any) => <div key={item.id}>{item.id}. {item.firstName}</div>)}
            <button onClick={()=> setPage(prev => prev-1)} disabled={page==0 ? true: false}>Prev Page</button>
            <button onClick={()=> setPage(prev => prev+1)} disabled={page==4 ? true: false}>Next Page</button>
        </div>
        </>
    )
}

