import { Link, useNavigate } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { Formik, Form, Field } from 'formik';
import * as Yup from 'yup';
import axios from 'axios';

interface FormData {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  confirmpassword: string;
  term: boolean;
  img?: File;
  companyAddress: string;
  companyCity: string;
  companyState: string;
  companyZip: string;
  homeAddress: string;
  city: string;
  state: string;
  zip: string;
  appointmentLetter?: File;
}

const SignupSchema = Yup.object().shape({
  firstName: Yup.string()
    .matches(/^[A-Za-z]+$/, 'First name must contain only letters')
    .max(20, 'First name must be at most 20 characters')
    .required('First name is required'),
  lastName: Yup.string()
    .matches(/^[A-Za-z]+$/, 'Last name must contain only letters')
    .max(20, 'Last name must be at most 20 characters')
    .required('Last name is required'),
  email: Yup.string().email('Invalid email').required('Email is required'),
  password: Yup.string()
    .required('Please enter your password')
    .matches(
      // eslint-disable-next-line no-useless-escape
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/,
      'Must contain 8 characters, one uppercase, one lowercase, one number and one special character'
    ),
  confirmpassword: Yup.string()
    .required('Required')
    .oneOf([Yup.ref('password')], 'Passwords must match'),
  term: Yup.boolean().oneOf([true], 'You must accept the terms and conditions'),
  companyAddress: Yup.string().required('Company address is required'),
  companyCity: Yup.string().required('Company city is required'),
  companyState: Yup.string().required('Company state is required'),
  companyZip: Yup.string()
    .matches(
      /^[A-Za-z0-9]{6}$/,
      'Zip must be exactly 6 characters and cannot contain special characters'
    )
    .required('Company zip is required'),
  homeAddress: Yup.string().required('Home address is required'),
  city: Yup.string().required('City is required'),
  state: Yup.string().required('State is required'),
  zip: Yup.string()
    .matches(
      /^[A-Za-z0-9]{6}$/,
      'Zip must be exactly 6 characters and cannot contain special characters'
    )
    .required('Zip is required'),

  img: Yup.mixed()
    .required('An image file is required')
    .test(
      'fileFormat',
      'Unsupported Format, only JPG and PNG allowed',
      (value) => {
        if (value && value instanceof File) {
          return value.type === 'image/jpeg' || value.type === 'image/png';
        }
        return false;
      }
    ),
  appointmentLetter: Yup.mixed().test(
    'fileFormat',
    'Only PDF files are supported',
    (value) => {
      if (value && value instanceof File) {
        return value.type === 'application/pdf';
      }
      return true; 
    }
  ),
});

export default function SignUp() {
  const navigate = useNavigate();

  const handleSubmit = async (values: FormData) => {
    try {
      const formData = new FormData();
   

      formData.append('firstName', values.firstName);
      formData.append('lastName', values.lastName);
      formData.append('email', values.email);
      formData.append('password', values.password);
    //   formData.append('userId', userId.toString());
      formData.append('companyAddress', values.companyAddress);
      formData.append('companyCity', values.companyCity);
      formData.append('companyState', values.companyState);
      formData.append('companyZip', values.companyZip);
      formData.append('homeAddress', values.homeAddress);
      formData.append('city', values.city);
      formData.append('state', values.state);
      formData.append('zip', values.zip);
      if (values.img) {
        formData.append('img', values.img);
      }
      if (values.appointmentLetter) {
        formData.append('appointmentLetter', values.appointmentLetter);
      }
       await axios.post(
        'http://localhost:3000/users',
        formData,
        {
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        }
      );
      alert('Registration successful!');
      navigate('/');
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
    } catch (error: any) {
      console.error(error);
      if (error.response && error.response.status === 409) {
        toast.error(error.response.data.message);
      } else {
        toast.error('Registration failed. Please try again.');
      }
    }
  };

  return (
    <div className="container">
      <h2>Please Signup</h2>
      <ToastContainer />
      <Formik
        initialValues={{
          firstName: '',
          lastName: '',
          email: '',
          password: '',
          confirmpassword: '',
          term: false,
          img: undefined, // Initialize img as undefined
          companyAddress: '',
          companyCity: '',
          companyState: '',
          companyZip: '',
          homeAddress: '',
          city: '',
          state: '',
          zip: '',
          appointmentLetter: undefined,
        }}
        validationSchema={SignupSchema}
        onSubmit={handleSubmit}
      >
        {({ setFieldValue, errors, touched }) => (
          <Form>
            <div className="form-row">
              <div className="form-group col-md-6">
                <label htmlFor="firstName">First Name</label>
                <Field
                  type="text"
                  className="form-control"
                  name="firstName"
                  id="firstName"
                  placeholder="First Name"
                />
                {errors.firstName && touched.firstName && (
                  <div className="text-danger">{errors.firstName}</div>
                )}
              </div>
              <div className="form-group col-md-6">
                <label htmlFor="lastName">Last Name</label>
                <Field
                  type="text"
                  className="form-control"
                  name="lastName"
                  id="lastName"
                  placeholder="Last Name"
                />
                {errors.lastName && touched.lastName && (
                  <div className="text-danger">{errors.lastName}</div>
                )}
              </div>
            </div>
            <div className="form-group">
              <label htmlFor="email">Email</label>
              <Field
                type="email"
                className="form-control"
                name="email"
                id="email"
                placeholder="Email"
              />
              {errors.email && touched.email && (
                <div className="text-danger">{errors.email}</div>
              )}
            </div>
            <div className="form-row">
              <div className="form-group col-md-6">
                <label htmlFor="password">Password</label>
                <Field
                  type="password"
                  className="form-control"
                  name="password"
                  id="password"
                  placeholder="Password"
                />
                {errors.password && touched.password && (
                  <div className="text-danger">{errors.password}</div>
                )}
              </div>
              <div className="form-group col-md-6">
                <label htmlFor="confirmpassword">Confirm Password</label>
                <Field
                  type="password"
                  className="form-control"
                  name="confirmpassword"
                  id="confirmpassword"
                  placeholder="Confirm Password"
                />
                {errors.confirmpassword && touched.confirmpassword && (
                  <div className="text-danger">{errors.confirmpassword}</div>
                )}
              </div>
            </div>
            <div className="form-group">
              <label htmlFor="companyAddress">companyAddress</label>
              <Field
                type="text"
                className="form-control"
                name="companyAddress"
                id="companyAddress"
                placeholder="companyAddress"
              />
              {errors.companyAddress && touched.companyAddress && (
                <div className="text-danger">{errors.companyAddress}</div>
              )}
            </div>
            <div className="form-group">
              <label htmlFor="companyCity">companyCity</label>
              <Field
                type="text"
                className="form-control"
                name="companyCity"
                id="companyCity"
                placeholder="companyCity"
              />
              {errors.companyCity && touched.companyCity && (
                <div className="text-danger">{errors.companyCity}</div>
              )}
            </div>
            <div className="form-group">
              <label htmlFor="companyState">companyState</label>
              <Field
                type="text"
                className="form-control"
                name="companyState"
                id="companyState"
                placeholder="companyState"
              />
              {errors.companyState && touched.companyState && (
                <div className="text-danger">{errors.companyState}</div>
              )}
            </div>
            <div className="form-group">
              <label htmlFor="companyZip">companyZip</label>
              <Field
                type="text"
                className="form-control"
                name="companyZip"
                id="companyZip"
                placeholder="companyZip"
              />
              {errors.companyZip && touched.companyZip && (
                <div className="text-danger">{errors.companyZip}</div>
              )}
            </div>
            <div className="form-group">
              <label htmlFor="homeAddress">homeAddress</label>
              <Field
                type="text"
                className="form-control"
                name="homeAddress"
                id="homeAddress"
                placeholder="homeAddress"
              />
              {errors.homeAddress && touched.homeAddress && (
                <div className="text-danger">{errors.homeAddress}</div>
              )}
            </div>
            <div className="form-group">
              <label htmlFor="city">city</label>
              <Field
                type="text"
                className="form-control"
                name="city"
                id="city"
                placeholder="city"
              />
              {errors.city && touched.city && (
                <div className="text-danger">{errors.city}</div>
              )}
            </div>
            <div className="form-group">
              <label htmlFor="state">state</label>
              <Field
                type="text"
                className="form-control"
                name="state"
                id="state"
                placeholder="state"
              />
              {errors.state && touched.state && (
                <div className="text-danger">{errors.state}</div>
              )}
            </div>
            <div className="form-group">
              <label htmlFor="zip">zip</label>
              <Field
                type="text"
                className="form-control"
                name="zip"
                id="zip"
                placeholder="zip"
              />
              {errors.zip && touched.zip && (
                <div className="text-danger">{errors.zip}</div>
              )}
            </div>
            <div className="mb-3">
              <label htmlFor="img" className="form-label">
                Upload Image (JPG, PNG)
              </label>
              <input
                className="form-control"
                type="file"
                id="img"
                name="img"
                onChange={(event) => {
                  const file = event.currentTarget.files![0];
                  setFieldValue('img', file);
                }}
              />
              {errors.img && touched.img && (
                <div className="text-danger">{errors.img}</div>
              )}
            </div>
            <div className="mb-3">
              <label htmlFor="appointmentLetter" className="form-label">
                Upload Appointment Letter (PDF)
              </label>
              <input
                className="form-control"
                type="file"
                id="appointmentLetter"
                name="appointmentLetter"
                onChange={(event) => {
                  const file = event.currentTarget.files![0];
                  setFieldValue('appointmentLetter', file);
                }}
              />
              {errors.appointmentLetter && touched.appointmentLetter && (
                <div className="text-danger">{errors.appointmentLetter}</div>
              )}
            </div>
            <div className="form-group form-check">
              <Field type="checkbox" className="form-check-input" name="term" />
              <label className="form-check-label" htmlFor="term">
                I accept the terms and conditions
              </label>
              {errors.term && <div className="text-danger">{errors.term}</div>}
            </div>
            <button type="submit" className="btn btn-primary">
              Signup
            </button>
          </Form>
        )}
      </Formik>
      <p>
        Already have an account? <Link to="/login">Login</Link>
      </p>
    </div>
  );
}
