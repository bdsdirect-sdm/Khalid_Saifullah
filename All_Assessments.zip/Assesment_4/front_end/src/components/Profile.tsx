/* eslint-disable @typescript-eslint/no-explicit-any */
import axios from "axios"
import { useQuery } from "@tanstack/react-query"
import { useParams } from "react-router-dom"

 
// const fetchUserDetails =(id:any)=>{
//     return axios.get(`http://localhost:3000/users/${id}`)
// }

// export default function Profile(){
//     const {id} = useParams()
//     const {data, isLoading, isError, error, isFetching} = useQuery({
//     queryKey:["details",id],
//     queryFn:()=> fetchUserDetails(id)
//     }) 

//     if(isLoading){
//         return<div>Page is Loading</div>
//     }

//     if(isError){
//         return<div>{error.message}</div>
//     }

//     // console.log("data...................",data)
//     console.log("loading...", isLoading)
//     console.log("Fetching.......", isFetching)
//     const {firstName, lastName,address,email} = data?.data || {}
//     return(
//         <>
//         <h1>Profile page</h1>
//         <div>{firstName}</div>
//         <div>{lastName}</div>
//         <div>{email}</div>
//         <div>{address.zip}</div>
//         </>
//     )
// }

const fetchUserDetails =(id:any)=>{
    return axios.get(`https://api.nationalize.io?name=${id}`)
}

export default function Profile(){
    const {id} = useParams()
    const {data, isLoading, isError, error, isFetching} = useQuery({
    queryKey:["details",id],
    queryFn:()=> fetchUserDetails(id)
    }) 

    if(isLoading){
        return<div>Page is Loading</div>
    }

    if(isError){
        return<div>{error.message}</div>
    }

    // console.log("data...................",data)
    console.log("loading...", isLoading)
    console.log("Fetching.......", isFetching)
    const {name,count,country} = data?.data || {}
    // console.log(country);
    const yourCountry = country?.[0]?.country_id;
    const chance = country?.[0]?.probability;
    
    return(
        <>
        <h1>Profile page</h1>
        <div>{name}</div>
        <div>{count}</div>
        <div>
                <h2>You are most probably from: {yourCountry}</h2>
                <h2>Probability: {Math.floor(chance*100)}%</h2>
                {/* {country?.map((item: { country_id: string }, index: number) => (
                    <div key={index}>Country ID: {item.country_id}</div>
                ))} */}
            </div>



        </>
    )
}
