/* eslint-disable @typescript-eslint/no-explicit-any */
import { useParams, useNavigate, Link } from 'react-router-dom';
import axios from 'axios';
import { Formik, Form, Field } from 'formik';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useQuery, useMutation } from '@tanstack/react-query';

interface User {
    id: number;
    firstName: string;
    lastName: string;
    email: string;
    dob: string;
    contact: string;
    gender: string;
    img?: File | null;
    companyAddress?: string;
    companyCity?: string;
    companyState?: string;
    companyZip?: string;
    homeAddress?: string;
    city?: string;
    state?: string;
    zip?: string;
    appointmentLetter?: File | null;
}

export default function UpdateProfile() {
    const { id } = useParams<{ id: string }>();
    const navigate = useNavigate();

    const { data: user, isLoading, isError, error } = useQuery({
        queryKey: ["details", id],
        queryFn: () => axios.get(`http://localhost:3000/users/${id}`).then(res => res.data)
    });

    const updateUser = (values: FormData) => {
        return axios.put(`http://localhost:3000/users/${id}`, values);
    }

    const { mutate,  } = useMutation({
        mutationFn: updateUser,
        onSuccess: () => toast.success("Profile updated successfully!"),
        // onError: () => toast.error(updateError?.message || "Update failed"),
    });

    if (isLoading) {
        return <div>Page is Loading...</div>;
    }

    if (isError) {
        return <div>Error: {error.message}</div>;
    }

    const initialValues: User = {
        ...user!,
        img: null,
        appointmentLetter: null,
        companyAddress: user?.address?.companyAddress || '',
        companyCity: user?.address?.companyCity || '',
        companyState: user?.address?.companyState || '',
        companyZip: user?.address?.companyZip || '',
        homeAddress: user?.address?.homeAddress || '',
        city: user?.address?.city || '',
        state: user?.address?.state || '',
        zip: user?.address?.zip || ''
    };

    return (
        <div className="container">
            <h2>Update Profile</h2>
            <ToastContainer />
            <Formik
                initialValues={initialValues}
                onSubmit={(values:any) => {
                    const formData = new FormData();
                    Object.keys(values).forEach((key) => {
                        if (key === 'img' || key === 'appointmentLetter') {
                            if (values[key]) {
                                formData.append(key, values[key]);
                            }
                        } else {
                            formData.append(key, values[key]);
                        }
                    });

                    mutate(formData);
                }}
            >
                {({ setFieldValue }) => (
                    <Form>
                        <div className="form-group">
                            <label htmlFor="firstName">First Name</label>
                            <Field
                                type="text"
                                className="form-control"
                                name="firstName"
                                id="firstName"
                            />
                        </div>
                        <div className="form-group">
                            <label htmlFor="lastName">Last Name</label>
                            <Field
                                type="text"
                                className="form-control"
                                name="lastName"
                                id="lastName"
                            />
                        </div>
                        <div className="form-group">
                            <label htmlFor="email">Email</label>
                            <Field
                                type="email"
                                className="form-control"
                                name="email"
                                id="email"
                            />
                        </div>
                        <h3>Company Address</h3>
                        <div className="form-group">
                            <label htmlFor="companyAddress">Company Address</label>
                            <Field
                                type="text"
                                className="form-control"
                                name="companyAddress"
                                id="companyAddress"
                            />
                        </div>
                        <div className="form-group">
                            <label htmlFor="companyCity">Company City</label>
                            <Field
                                type="text"
                                className="form-control"
                                name="companyCity"
                                id="companyCity"
                            />
                        </div>
                        <div className="form-group">
                            <label htmlFor="companyState">Company State</label>
                            <Field
                                type="text"
                                className="form-control"
                                name="companyState"
                                id="companyState"
                            />
                        </div>
                        <div className="form-group">
                            <label htmlFor="companyZip">Company Zip</label>
                            <Field
                                type="text"
                                className="form-control"
                                name="companyZip"
                                id="companyZip"
                            />
                        </div>
                        
                        <h3>Home Address</h3>
                        <div className="form-group">
                            <label htmlFor="homeAddress">Home Address</label>
                            <Field
                                type="text"
                                className="form-control"
                                name="homeAddress"
                                id="homeAddress"
                            />
                        </div>
                        <div className="form-group">
                            <label htmlFor="city">City</label>
                            <Field
                                type="text"
                                className="form-control"
                                name="city"
                                id="city"
                            />
                        </div>
                        <div className="form-group">
                            <label htmlFor="state">State</label>
                            <Field
                                type="text"
                                className="form-control"
                                name="state"
                                id="state"
                            />
                        </div>
                        <div className="form-group">
                            <label htmlFor="zip">Zip</label>
                            <Field
                                type="text"
                                className="form-control"
                                name="zip"
                                id="zip"
                            />
                        </div>

                        <div className="form-group">
                            <label htmlFor="img">Upload Image</label>
                            <input
                                className="form-control"
                                type="file"
                                id="img"
                                name="img"
                                onChange={(event) => {
                                    const file = event.currentTarget.files![0];
                                    setFieldValue('img', file);
                                }}
                            />
                        </div>
                        <div className="form-group">
                            <label htmlFor="appointmentLetter">Upload Appointment Letter</label>
                            <input
                                className="form-control"
                                type="file"
                                id="appointmentLetter"
                                name="appointmentLetter"
                                onChange={(event) => {
                                    const file = event.currentTarget.files![0];
                                    setFieldValue('appointmentLetter', file);
                                }}
                            />
                        </div>

                        <button type="submit" className="btn btn-primary mb-4">
                            Update Profile
                        </button>
                    </Form>
                )}
            </Formik>
            <div className="d-flex">
                <button onClick={() => navigate('/login')} className="btn btn-danger mr-4">
                    Logout
                </button>
                <button type="button" className="btn btn-info">
                    <Link className="text-white" to={`/profile/${id}`}>
                        Cancel
                    </Link>
                </button>
            </div>
        </div>
    );
}
