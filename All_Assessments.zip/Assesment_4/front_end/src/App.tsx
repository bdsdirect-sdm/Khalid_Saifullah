
// import './App.css'
import SignUp from './components/SignUp'
import Profile from './components/Profile'
import UpdateProfile from './components/UpdateProfile'
import { BrowserRouter, Route, Routes } from "react-router-dom"
import UserList from './components/UserList'

function App() {

  return (
    <>
       <div className="App container">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<SignUp />} />
          <Route path="profile/:id" element={<Profile />} />
          <Route path="update/:id" element={<UpdateProfile />} />
          <Route path="userlist" element={<UserList />} />
          {/* <Route path="login" element={<Login />} /> */}
        </Routes>
      </BrowserRouter>
      {/* <Login/> */}
    </div>
    </>
  )
}

export default App
