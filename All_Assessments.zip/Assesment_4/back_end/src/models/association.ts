import Userdetails from './UserDetails';
import UserAddress from './UserAddress';

// Define associations
Userdetails.hasOne(UserAddress, { foreignKey: 'userId', as: 'address' });
UserAddress.belongsTo(Userdetails, { foreignKey: 'userId', as: 'user' });
