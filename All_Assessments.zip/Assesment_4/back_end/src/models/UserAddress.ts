import { DataTypes, Model } from 'sequelize';
import sequelize from '../config/database';

class UserAddress extends Model {
  public id!: number;
  public userId!: number; // Ensure this is present
  public companyAddress!: string;
  public companyCity!: string;
  public companyState!: string;
  public companyZip!: string;
  public homeAddress!: string;
  public city!: string;
  public state!: string;
  public zip!: string;
  public appointmentLetter?: string;
}

UserAddress.init(
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    userId: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'UserDetails', // Ensure this references the correct table
        key: 'id',
      },
    },
    companyAddress: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    companyCity: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    companyState: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    companyZip: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    homeAddress: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    city: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    state: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    zip: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    appointmentLetter: {
      type: DataTypes.STRING,
      allowNull: true,
    },
  },
  {
    sequelize,
    modelName: 'UserAddress',
    // tableName: 'user_addresses', // Ensure this matches your database table name
  }
);

export default UserAddress;
