import UserAddress from "../models/UserAddress";
import UserDetails from "../models/UserDetails";
const bcrypt = require('bcrypt');
var jwt = require('jsonwebtoken');
import {httpStatusCodes} from "../../constants"
import { sendWelcomeEmail } from '../mail/nodemailerConfig';

import dotenv from 'dotenv';
dotenv.config();



export const hello = (req:any,res:any)=>{
    res.send("Welcome from home")
}

export const addUser = async(req:any, res:any,next:any)=>{
    try{
        // console.log(req.body,"req.body in addUser")
        const {firstName, lastName, email, password,img} = req.body;
        const { userId, companyAddress, companyCity, companyState, companyZip, homeAddress, city, state, zip,appointmentLetter } = req.body;

        const existingUser = await UserDetails.findOne({ where: { email } });
        if(existingUser){
            return res.status(httpStatusCodes.CONFLICT).json({message:'Email already exists'})
        }
        const hashedPassword = await bcrypt.hash(password, 10);

        // const imgPath = req.file ? req.file.path : null;
        const imgPath = req.files['img'] ? req.files['img'][0].path : null;
        const user = await UserDetails.create({firstName,lastName,email,password:hashedPassword,img:imgPath})

        const appoinPath = req.files['appointmentLetter'] ? req.files['appointmentLetter'][0].path : null;
        const userAddress = await UserAddress.create({
        userId:user.id,
        companyAddress,
        companyCity,
        companyState,
        companyZip,
        homeAddress,
        city,
        state,
        zip,
        appointmentLetter:appoinPath,
        })
        // await sendWelcomeEmail(user.email, user.firstName);
        res.status(httpStatusCodes.OK).json(user)
    }catch(error:any){
        res.status(httpStatusCodes.BAD_REQUEST).json({error:error.message})
    }
}

  export const getUserById = async (req: any, res: any) => {
    try {
      const user = await UserDetails.findByPk(req.params.id,{
        include: [
            {
                model: UserAddress,
                as: 'address' // Use the alias defined in the association
            }
        ],
    });
      res.status(httpStatusCodes.OK).json(user);

    } catch (error) {
      console.error('Error fetching user:', error);
      res.status(httpStatusCodes.INTERNAL_SERVER_ERROR).json({ error: 'Error fetching user' });
    }
  };

  export const updateUser = async(req:any, res:any)=>{
    try{
        const user = await UserDetails.findByPk(req.params.id);
        if(!user){
            return res.status(httpStatusCodes.NOT_FOUND).json({message:"user not found"})
        }
        // fs.unlink()
        const{firstName, lastName, email, img} = req.body;
        const imgPath = req.files['img'] ? req.files['img'][0].path : null;
        const updatedUser = await user.update({firstName,lastName,email,img:imgPath})

        const address = await UserAddress.findOne({ where: { userId: req.params.id } });
        if(address){
            const { userId , companyAddress, companyCity, companyState, companyZip, homeAddress, city, state, zip,appointmentLetter } = req.body;
            const appoinPath = req.files['appointmentLetter'] ? req.files['appointmentLetter'][0].path : null;
            await address.update({
                userId:user.id, companyAddress, companyCity, companyState, companyZip, homeAddress, city, state, zip,appointmentLetter:appoinPath
            })
        }else {
            await UserAddress.create({ ...req.body, userId: user.id });
          }
          res.status(httpStatusCodes.OK).json(user);
    }catch(err){
        console.error('Error updating user:', err);
      res.status(httpStatusCodes.INTERNAL_SERVER_ERROR).json({ error: 'Error updating user' });
    }
  }

export const login = async(req:any,res:any)=>{
    try{
        const {email , password} = req.body;
        const user = await UserDetails.findOne({where:{email}})
        // console.log("user.data......",user)
        if (!user) {
            return res.status(httpStatusCodes.NOT_FOUND).json({ message: 'User not found' });
        }
        const isPasswordValid = await bcrypt.compare(password, user.password)
        if(!isPasswordValid){
            return res.status(httpStatusCodes.UN_AUTHORIZED).json({ message: 'Invalid credentials' });
        }
        const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET, { expiresIn: '1h' });
        res.status(httpStatusCodes.OK).json({ message: 'Login successful', token, userId: user.id });
    }catch(err:any){
        res.status(httpStatusCodes.INTERNAL_SERVER_ERROR).json({ message: err.message });
    }
}

  // export const getAllUser = async (req: any, res: any) => {
  //   try {
  //     const user = await UserDetails.findAll();
  //     res.status(httpStatusCodes.OK).json(user);

  //   } catch (error) {
  //     console.error('Error fetching user:', error);
  //     res.status(httpStatusCodes.INTERNAL_SERVER_ERROR).json({ error: 'Error fetching user' });
  //   }
  // };

export const getAllUser = async (req:any, res:any) => {
    const page = parseInt(req.query._page) || 1;
    const limit = parseInt(req.query._limit) || 4; 
    const offset = (page - 1) * limit; 

    try {
        const users = await UserDetails.findAll({
            limit: limit,
            offset: offset
        });

        const totalUsers = await UserDetails.count();

        res.status(httpStatusCodes.OK).json({
            data: users,
            total: totalUsers,
            page,
            totalPages: Math.ceil(totalUsers / limit)
        });
    } catch (error) {
        console.error('Error fetching users:', error);
        res.status(httpStatusCodes.INTERNAL_SERVER_ERROR).json({ error: 'Error fetching users' });
    }
};
