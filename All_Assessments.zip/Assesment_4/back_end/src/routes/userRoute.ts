import express from 'express';
import { addUser, getAllUser, getUserById, hello, login, updateUser } from '../controller/userController';
import { upload } from '../middleware/upload';
import { validateUser } from '../middleware/validateUser';

const router = express.Router();

router.get('/', hello);
router.post('/users', upload.fields([{name:"img"},{name:"appointmentLetter"}]),validateUser, addUser);
router.get('/users/:id', getUserById);
router.put('/users/:id',upload.fields([{name:"img"},{name:"appointmentLetter"}]), updateUser);
router.post('/login', login);
router.get('/users', getAllUser);

export default router;