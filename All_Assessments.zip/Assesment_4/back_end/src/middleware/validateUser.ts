import Joi from "joi"
import { httpStatusCodes } from "../../constants"
export const validateUser =(req:any,res:any,next:any)=>{
    const validateUserSchema=Joi.object({
        firstName:Joi.string().required(),
        lastName:Joi.string().required(),
        email:Joi.string().email().required(),
        password:Joi.string().min(8).required(),
        companyAddress:Joi.string().required(),
           companyCity:Joi.string().required(),
        companyState:Joi.string().required(),
        companyZip:Joi.string().required().min(6),
        homeAddress:Joi.string().required(),
        city:Joi.string().required(),
        state:Joi.string().required(),
        zip:Joi.string().required().min(6),
    })
    const {error}=validateUserSchema.validate(req.body)
    if(error){
        const msg = error.details.map(el=>el.message).join(',')
        return res.status(httpStatusCodes.CONFLICT).json({message:msg})
    }
    next()
}
