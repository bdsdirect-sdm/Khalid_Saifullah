import sequelize from './src/config/database';
import UserDetails from "./src/models/UserDetails";
import UserAddress from "./src/models/UserAddress";
import express, {  Request, Response } from 'express';
import userRoute from "./src/routes/userRoute";
import './src/models/association';
import path from 'path';
const CORS = require('cors');

const app = express();
app.use(express.json());
app.use(express.json());
app.use(CORS({
    origin: true,
    optionsSuccessStatus: 200 
}));
app.use( express.static(path.join(__dirname,'uploads')))
app.use("/uploads", express.static(path.join(__dirname,'uploads')))

app.use('/',userRoute);

const startServer = async () => {
    try {
        await sequelize.authenticate();
        console.log('Database connected.');

        await UserDetails.sync({ force: false });
        await UserAddress.sync({ force: false });

        app.listen(3000, () => {
            console.log('Server is running http://localhost:3000');
        });
    } catch (error: any) {
        console.error('Unable to connect to the database:', error);
    }
};

startServer();