import { Sequelize } from 'sequelize';

const sequelize = new Sequelize('assessment6', 'root', 'Password123#@!', {
  host: 'localhost',
  dialect: 'mysql',
  logging: false
});

export default sequelize;