import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

export default function Navbar(){
    const navigate = useNavigate();
    const handleLogout = () => {
        localStorage.removeItem('token');
        toast.success('Successfully Logged Out');
        navigate('/login');
      };
    return(
        <nav className="navbar navbar-expand-lg navbar-primary bg-primary">
        <div className="container-fluid">
          <Link to="/profile" className="navbar-brand text-white">
            Home
          </Link>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse justify-content-end" id="navbarNav">
            <ul className="navbar-nav">
              <li className="nav-item me-3">
                <Link to="/profile" className="nav-link text-white">
                  Home
                </Link>
              </li>
              <li className="nav-item">
                <button
                  onClick={handleLogout}
                  className="btn btn-danger"
                >
                  Logout
                </button>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    )
}