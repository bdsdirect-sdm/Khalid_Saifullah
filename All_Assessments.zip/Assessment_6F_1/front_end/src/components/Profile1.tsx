/* eslint-disable @typescript-eslint/no-explicit-any */
import { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { baseURL } from '../../environments/environment';
import axios from 'axios';
import { jwtDecode } from 'jwt-decode';
import { v4 as uuidv4 } from 'uuid';
import ChatPopup from './ChatPopup'; // Import the ChatPopup component

interface JobSeeker {
    status: any;
    isApproved: any;
    id: number;
    firstName: string;
    lastName: string;
    email: string;
    contact: string;
    resume: string | null;
    profileImg: string | null;
    gender: string;
    Agency: {
        contact: string;
        id: number;
        firstName: string;
        lastName: string;
        email: string;
        profileImg: string | null;
    } | null;
}

interface Agency {
    id: number;
    firstName: string;
    lastName: string;
    email: string;
    profileImg: string | null;
    gender: string;
    JobSeekers: JobSeeker[];
}

const Profile = () => {
    const [userData, setUserData] = useState<JobSeeker | Agency | null>(null);
    const [isChatOpen, setIsChatOpen] = useState<boolean>(false); // State to manage chat popup visibility
    const [roomId, setRoomId] = useState<string | null>(null); // Room ID state
    const navigate = useNavigate();

    useEffect(() => {
        const fetchUserDetails = async () => {
            try {
                const token: any = localStorage.getItem('token');
                if (!token) {
                    return navigate('/login');
                }
                const decoded: any = jwtDecode(token);
                const { userId } = decoded.id;
                const response = await axios.get(`${baseURL}userDetails/${userId}`, {
                    headers: { Authorization: `Bearer ${token}` },
                });
                setUserData(response.data);
            } catch (error) {
                console.error('Error fetching user details:', error);
            }
        };

        fetchUserDetails();
    }, [navigate]);

    if (!userData) {
        return <div className="text-center text-danger">User not found.</div>;
    }

    const handleApprovalChange = async (userId: number, status: boolean) => {
        const token = localStorage.getItem('token');
        try {
            await axios.patch(`${baseURL}userApproval/${userId}`, { isApproved: status }, {
                headers: { Authorization: `Bearer ${token}` },
            });
            alert('Status updated successfully');
        } catch (error) {
            console.error('Error updating status:', error);
        }
    };

    const handleLogout = () => {
        localStorage.removeItem('token');
        alert('Successfully Logged Out');
        navigate('/login');
    };

    const isJobSeeker = (user: JobSeeker | Agency): user is JobSeeker => {
        return (user as JobSeeker).Agency !== undefined;
    };

    const openChat = (jobSeekerId?: number) => {
        if (isJobSeeker(userData)) {
            if (userData.isApproved && userData.Agency) {
                const jobseekerId = userData.id;
                const agencyId = userData.Agency.id;
                const newRoomId = uuidv4(); // Generate a unique room ID
                setRoomId(newRoomId);
                setIsChatOpen(true);
            }
        } else {
            if (jobSeekerId) {
                const agencyId = userData.id;
                const newRoomId = uuidv4(); // Generate a unique room ID
                setRoomId(newRoomId);
                setIsChatOpen(true);
            }
        }
    };

    return (
        <>
            {/* Navbar */}
            <nav className="navbar navbar-expand-lg navbar-primary bg-primary">
                <div className="container-fluid">
                    <Link to="/profile" className="navbar-brand text-white">
                        Home
                    </Link>
                    <button
                        className="navbar-toggler"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#navbarNav"
                        aria-controls="navbarNav"
                        aria-expanded="false"
                        aria-label="Toggle navigation"
                    >
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse justify-content-end" id="navbarNav">
                        <ul className="navbar-nav">
                            <li className="nav-item me-3">
                                <Link to="/profile" className="nav-link text-white">
                                    Home
                                </Link>
                            </li>
                            <li className="nav-item">
                                <button
                                    onClick={handleLogout}
                                    className="btn btn-danger"
                                >
                                    Logout
                                </button>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>

            {/* Profile Content */}
            <div className="container mt-5">
                <h2 className="text-center mb-4 profile-header">
                    {isJobSeeker(userData) ? 'Job Seeker Profile' : 'Agency Profile'}
                </h2>
                <div className="card mb-4 shadow-lg profile-card">
                    <div className="card-body">
                        <h3 className="card-title">
                            {userData.firstName} {userData.lastName}
                        </h3>
                        <p className="card-text">
                            <strong>Email:</strong> {userData.email}
                        </p>
                        <p className="card-text">
                            <strong>Gender:</strong> {userData.gender}
                        </p>
                        <img
                            src={`${baseURL}${userData.profileImg}`}
                            alt="profileImg"
                            className="img-fluid rounded profile-img"
                        />

                        {isJobSeeker(userData) && (
                            <>
                                <p className="card-text">
                                    <strong>Contact: </strong> {userData.contact}
                                </p>
                                {userData.resume && (
                                    <p className="card-text">
                                        <strong>Resume:</strong>{' '}
                                        <a
                                            href={`${baseURL}${userData.resume}`}
                                            target="_blank"
                                            className="btn btn-link resume-link"
                                        >
                                            Download
                                        </a>
                                    </p>
                                )}
                                <p className="card-text">
                                    <strong>Current Status:</strong>{' '}
                                    {userData.isApproved ? 'Approved' : 'Pending Approval'}
                                </p>
                                {userData.isApproved && userData.Agency && (
                                    <button
                                        onClick={() => openChat()}
                                        className="btn btn-primary mt-3 chat-btn"
                                    >
                                        Chat with Agency
                                    </button>
                                )}
                                {userData.Agency && (
                                    <div className="mt-4">
                                        <h4>Agency Details:</h4>
                                        <p>
                                            <strong>Name:</strong> {userData.Agency.firstName}{' '}
                                            {userData.Agency.lastName}
                                        </p>
                                        <p>
                                            <strong>Email:</strong> {userData.Agency.email}
                                        </p>
                                        <p>
                                            <strong>Contact No:</strong> {userData.Agency.contact}
                                        </p>
                                        {userData.Agency.profileImg && (
                                            <img
                                                src={`${baseURL}${userData.Agency.profileImg}`}
                                                alt="Agency"
                                                className="img-fluid rounded agency-img"
                                            />
                                        )}
                                    </div>
                                )}
                            </>
                        )}

                        {!isJobSeeker(userData) && (
                            <div className="mt-4">
                                <h4>Job Seekers:</h4>
                                <table className="table table-striped table-hover">
                                    <thead className="thead-dark">
                                        <tr>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Contact</th>
                                            <th>Gender</th>
                                            <th>Resume</th>
                                            <th>Status</th>
                                            <th>Actions</th>
                                            <th>Contact</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {userData.JobSeekers.map((jobSeeker) => (
                                            <tr key={jobSeeker.id}>
                                                <td>{jobSeeker.firstName} {jobSeeker.lastName}</td>
                                                <td>{jobSeeker.email}</td>
                                                <td>{jobSeeker.contact}</td>
                                                <td>{jobSeeker.gender}</td>
                                                <td>
                                                    <a
                                                        href={`${baseURL}${jobSeeker.resume}`}
                                                        target="_blank"
                                                        className="btn btn-link resume-link"
                                                    >
                                                        Download Resume
                                                    </a>
                                                </td>
                                                <td>
                                                    <span className={`status-label ${jobSeeker.isApproved ? 'approved' : 'rejected'}`}>
                                                        {jobSeeker.isApproved ? 'Approved' : 'Rejected'}
                                                    </span>
                                                </td>
                                                <td>
                                                    <select
                                                        onChange={(e) =>
                                                            handleApprovalChange(
                                                                jobSeeker.id,
                                                                e.target.value === 'true'
                                                            )
                                                        }
                                                        value={jobSeeker.isApproved ? 'true' : 'false'}
                                                        className="form-control form-control-sm"
                                                    >
                                                        <option value="true">Approve</option>
                                                        <option value="false">Reject</option>
                                                    </select>
                                                </td>
                                                <td>
                                                    <button
                                                        onClick={() => openChat(jobSeeker.id)}
                                                        className="btn btn-primary"
                                                    >
                                                        Chat
                                                    </button>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        )}
                    </div>
                </div>

                {isChatOpen && roomId && (
                    <ChatPopup roomId={roomId} onClose={() => setIsChatOpen(false)} />
                )}
            </div>
        </>
    );
};

export default Profile;
