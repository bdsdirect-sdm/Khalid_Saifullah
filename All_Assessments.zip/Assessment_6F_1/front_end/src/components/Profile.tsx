/* eslint-disable @typescript-eslint/no-explicit-any */
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { baseURL } from '../../environments/environment';
import axios from 'axios';
import { jwtDecode } from 'jwt-decode';
import { v4 as uuidv4 } from 'uuid';
import Navbar from './NavBar';
import { toast, ToastContainer } from 'react-toastify';

interface JobSeeker {
  status: any;
  isApproved: string; 
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  contact: string;
  resume: string | null;
  profileImg: string | null;
  gender: string;
  Agency: {
    contact: string;
    id: number;
    firstName: string;
    lastName: string;
    email: string;
    profileImg: string | null;
  } | null;
}

interface Agency {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  profileImg: string | null;
  gender: string;
  JobSeekers: JobSeeker[];
}

const Profile = () => {
  const [userData, setUserData] = useState<JobSeeker | Agency | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchUserDetails = async () => {
      try {
        const token: any = localStorage.getItem('token');
        if (!token) {
          return navigate('/login');
        }
        const decoded: any = jwtDecode(token);
        const { userId } = decoded.id;
        const response = await axios.get(`${baseURL}userDetails/${userId}`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        setUserData(response.data);
      } catch (error) {
        console.error('Error fetching user details:', error);
      }
    };

    fetchUserDetails();
  }, [navigate]);

  if (!userData) {
    return <div className="text-center text-danger">
      <div className="spinner-border" role="status">
    <span className="sr-only">Loading...</span>
  </div>
  </div>;
  }

  const handleApprovalChange = async (userId: number, status: string) => { 
    const token = localStorage.getItem('token');
    try {
      await axios.patch(`${baseURL}userApproval/${userId}`, { isApproved: status }, {
        headers: { Authorization: `Bearer ${token}` },
      });
      // for realtime status showing
      if (!isJobSeeker(userData)) {
        const updatedJobSeekers = userData.JobSeekers.map((jobSeeker) => {
          if (jobSeeker.id === userId) {
            return { ...jobSeeker, isApproved: status };
          }
          return jobSeeker;
        });
        setUserData({ ...userData, JobSeekers: updatedJobSeekers });
      }
      toast.success('Status updated successfully');
    } catch (error) {
      console.error('Error updating status:', error);
    }
  };
  const isJobSeeker = (user: JobSeeker | Agency): user is JobSeeker => {
    return (user as JobSeeker).Agency !== undefined;
  };

  const openChat = async (jobSeekerId?: number) => {
    try {
      if (isJobSeeker(userData)) {
        if (userData.isApproved === "1" && userData.Agency) { 
          const jobseekerId = userData.id;
          const agencyId = userData.Agency.id;
          const roomId = uuidv4();
          const response = await axios.post(`${baseURL}chat/createRoom`, {
            jobseekerId,
            agencyId,
            roomId,
          });
          navigate(`/chat/${response.data.roomId}`);
        }
      } else {
        if (jobSeekerId) {
          const agencyId = userData.id;
          const roomId = uuidv4();
          const response = await axios.post(`${baseURL}chat/createRoom`, {
            jobseekerId: jobSeekerId,
            agencyId,
            roomId,
          });
          navigate(`/chat/${response.data.roomId}`);
        }
      }
    } catch (error) {
      console.error('Error creating chat room:', error);
    }
  };

  return (
    <>
      <ToastContainer/>
      {/* Navbar */}
     <Navbar/>
      {/* Profile */}
      <div className="container mt-5">
        <h2 className="text-center mb-4 profile-header">
          {isJobSeeker(userData) ? 'Job Seeker Profile' : 'Agency Profile'}
        </h2>
        <div className="d-flex justify-content-between">
          <div className="profile-left">
            <div className="card mb-4 shadow-lg profile-card">
              <div className="card-body">
                <img
                  src={`${baseURL}${userData.profileImg}`}
                  alt="profileImg"
                  className="img-fluid rounded profile-img"
                />
                <h3 className="card-title">
                  {userData.firstName} {userData.lastName}
                </h3>
                <p className="card-text">
                  <strong>Email:</strong> {userData.email}
                </p>
                <p className="card-text">
                  <strong>Gender:</strong> {userData.gender}
                </p>
                {isJobSeeker(userData) && (
                  <>
                    <p className="card-text">
                      <strong>Contact: </strong> {userData.contact}
                    </p>
                    {userData.resume && (
                      <p className="card-text">
                        <strong>Resume:</strong>{' '}
                        <a
                          href={`${baseURL}${userData.resume}`}
                          target="_blank"
                          className="btn btn-link resume-link"
                        >
                          Download
                        </a>
                      </p>
                    )}
                    <p className="card-text">
                      <strong>Current Status:</strong>{' '}
                      {userData.isApproved === "1"
                        ? 'Approved'
                        : userData.isApproved === "2"
                        ? 'Rejected'
                        : 'Pending Approval'}
                    </p>
                    {userData.isApproved === "1" && userData.Agency && (
                      <button
                        onClick={() => openChat()}
                        className="btn btn-primary mt-3 chat-btn"
                      >
                        Chat with Agency
                      </button>
                    )}
                  </>
                )}
              </div>
            </div>
          </div>

          {/* Agency Details */}
          {isJobSeeker(userData) && userData.Agency && (
            <div className="profile-right">
              <div className="card mb-4 shadow-lg profile-card">
                <div className="card-body">
                  <h4>Agency Details:</h4>
                  {userData.Agency.profileImg && (
                    <img
                      src={`${baseURL}${userData.Agency.profileImg}`}
                      alt="Agency"
                      className="img-fluid rounded agency-img"
                    />
                  )}
                  <p>
                    <strong>Name:</strong> {userData.Agency.firstName} {userData.Agency.lastName}
                  </p>
                  <p>
                    <strong>Email:</strong> {userData.Agency.email}
                  </p>
                  <p>
                    <strong>Contact No:</strong> {userData.Agency.contact}
                  </p>
                 
                </div>
              </div>
            </div>
          )}
        </div>

        {/* When user is Agency  */}
        {!isJobSeeker(userData) && (
          <div className="mt-4">
            <h4>Job Seekers:</h4>
            <table className="table table-striped table-hover">
              <thead className="thead-dark">
                <tr>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Contact</th>
                  <th>Gender</th>
                  <th>Resume</th>
                  <th>Status</th>
                  <th>Actions</th>
                  <th>Contact</th>
                </tr>
              </thead>
              <tbody>
                {userData.JobSeekers.map((jobSeeker) => (
                  <tr key={jobSeeker.id}>
                    <td>{jobSeeker.firstName} {jobSeeker.lastName}</td>
                    <td>{jobSeeker.email}</td>
                    <td>{jobSeeker.contact}</td>
                    <td>{jobSeeker.gender}</td>
                    <td>
                      <a href={`${baseURL}${jobSeeker.resume}`} target="_blank" className="btn btn-link resume-link">Download Resume</a>
                    </td>
                    <td>
                      <span className={`status-label ${jobSeeker.isApproved === "1" ? 'approved' : jobSeeker.isApproved === "2" ? 'rejected' : 'pending'}`}>
                      {jobSeeker.isApproved === "1"
                        ? 'Approved'
                        : jobSeeker.isApproved === "2"
                        ? 'Rejected'
                        : 'Pending'}
                      </span>
                    </td>
                    <td>
                      <select
                        onChange={(e) =>
                          handleApprovalChange(jobSeeker.id, e.target.value)
                        }
                        value={jobSeeker.isApproved}
                        className="form-control form-control-sm"
                      >
                        <option value="0">Pending</option>
                        <option value="1">Approve</option>
                        <option value="2">Reject</option>
                      </select>
                    </td>
                    <td>
                      {jobSeeker.isApproved === "1" && (
                        <button
                          onClick={() => openChat(jobSeeker.id)}
                          className="btn btn-primary ml-2 chat-btn"
                        >
                          Chat
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </>
  );
};

export default Profile;
