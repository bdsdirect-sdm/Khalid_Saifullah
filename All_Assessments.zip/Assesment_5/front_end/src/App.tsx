
import './App.css'

import { BrowserRouter, Route, Routes } from "react-router-dom"
import Login from "./components/Login"
import SignUp from "./components/SignUp"
import Profile from "./components/Profile"
import LoginReg from './components/LoginReg'

function App() {

  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<SignUp />} />
          {/* <Route path="profile/:userId" element={<Profile />} /> */}
          <Route path="profile" element={<Profile />} />
          <Route path="login" element={<Login />} />
          <Route path="*" element={<Login />} />
          <Route path="loginreg" element={<LoginReg />} />
        </Routes>
      </BrowserRouter>
    </>
  )
}

export default App
