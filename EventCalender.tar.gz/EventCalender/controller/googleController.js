const fs = require("fs");
const { google } = require("googleapis");
const path = require("path");

const calendar = google.calendar({
  version: "v3",
  auth: process.env.API_KEY
})

const SCOPES = ["https://www.googleapis.com/auth/calendar.events"];
const token = ""

const oAuth2Client = new google.auth.OAuth2(
  process.env.GOOGLE_CLIENT_ID,
  process.env.GOOGLE_CLIENT_SECRET,
  process.env.REDIRECT_URL,
)

// Generate Google OAuth URL
exports.getAuthUrl = (req, res) => {
  try {
    const authUrl = oAuth2Client.generateAuthUrl({
      access_type: "offline",
      scope: SCOPES,
    });

    res.redirect(authUrl);
  } catch (error) {
    console.error("Error generating auth URL:", error.message);
    res.status(500).json({
      message: "Failed to generate authentication URL.",
      error: error.message,
    });
  }
};


// Handle Google OAuth Callback
exports.handleCallback = async (req, res) => {
  try {
    const code = req.query.code;

    const { tokens } = await oAuth2Client.getToken(code);
    oAuth2Client.setCredentials(tokens);

    res.status(200).json({
      message: "Authentication Logged in successful! ",
      tokens,
    });
  } catch (error) {
    console.error("Error during callback handling:", error.message);
    res.status(500).json({
      message: "Authentication failed.",
      error: error.message,
    });
  }
};


// exports.scheduleEvents = async (req, res) => {
//   try{
//     const { start_time, end_time, summary, description, location } = req.body;
//     const response = await calendar.events.insert({
//       calendarId: "primary",
//       auth: oAuth2Client,
//       conferenceDataVersion: 1,
//       requestBody:{
//         summary,
//         description,
//         location,
//         start: {
//           dateTime: start_time,
//           timeZone: "Asia/Kolkata"
//         },
//         end: {
//           dateTime: end_time,
//           timeZone: "Asia/Kolkata"
//         }
//       }
//     })
//     res.status(200).json({
//       message: "Event Scheduled successful! ",
//       eventId: response.data.id
//     });
    
//   }catch(err){
//     res.status(500).json({message: "Error scheduling events"});
//   }
// }

// recuring events
exports.scheduleEvents = async (req, res) => {
  try {
    const {
      start_time,
      end_time,
      title,
      description,
      location,
      repeats,
      repeat_every,
      repeat_untill,
      selectedDays,
      occurance,
    } = req.body;

    // Base event object
    const event = {
      summary: title,
      description,
      location,
      start: {
        dateTime: `${req.body.start_date}T${start_time}:00`,
        timeZone: "Asia/Kolkata",
      },
      end: {
        dateTime: `${req.body.start_date}T${end_time}:00`,
        timeZone: "Asia/Kolkata",
      },
    };

    // Handle recurrence
    if (repeats) {
      let recurrenceRule = `RRULE:`;
      const repeatUntilDate = new Date(repeat_untill).toISOString().split("T")[0].replace(/-/g, "");
      
      if (repeat_every === "week" && selectedDays && selectedDays.length) {
        // Weekly recurrence on specific days
        const daysMap = {
          sunday: "SU",
          monday: "MO",
          tuesday: "TU",
          wednesday: "WE",
          thursday: "TH",
          friday: "FR",
          saturday: "SA",
        };
        const days = [...new Set(selectedDays)].map(day => daysMap[day.toLowerCase()]).join(",");
        recurrenceRule += `FREQ=WEEKLY;BYDAY=${days}`;
      } else if (repeat_every === "custom" && occurance > 0) {
        // Custom recurrence with a specific occurrence limit
        recurrenceRule += `FREQ=DAILY;COUNT=${occurance}`;
      } else if (repeat_every === "day") {
        // Daily recurrence
        recurrenceRule += `FREQ=DAILY`;
      }
      // Add the UNTIL date if it exists
      if (repeat_untill) {
        recurrenceRule += `;UNTIL=${repeatUntilDate}`;
      }
      // Add the recurrence rule to the event
      event.recurrence = [recurrenceRule];
    }

    // Schedule the event
    const response = await calendar.events.insert({
      calendarId: "primary",
      auth: oAuth2Client,
      conferenceDataVersion: 1,
      requestBody: event,
    });

    // Respond with success
    res.status(200).json({
      message: "Event Scheduled successfully!",
      eventId: response.data.id,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Error scheduling events" });
  }
};

// eventId : dbudtmnrd3j4cvahsg3fqk9f3g

// Updating an existing event using event id
exports.updateEvent = async (req, res) => {
  try {
    const { eventId } = req.query;
    const { start_time, end_time, summary, description, location } = req.body;

    const response = await calendar.events.update({
      calendarId: "primary",
      eventId: eventId,
      auth: oAuth2Client,
      requestBody: {
        summary,
        description,
        location,
        start: {
          dateTime: start_time,
          timeZone: "Asia/Kolkata",
        },
        end: {
          dateTime: end_time,
          timeZone: "Asia/Kolkata",
        },
      },
    });

    res.status(200).json({
      message: "Event updated successfully!",
      eventId: response.data.id,
    });
  } catch (err) {
    console.error("Error updating event:", err.message);
    res.status(500).json({
      message: "Error updating event",
      error: err.message,
    });
  }
};

// Delete an event
exports.deleteEvent = async (req, res) => {
  try {
    const { eventId } = req.query;

    await calendar.events.delete({
      calendarId: "primary",
      eventId: eventId, 
      auth: oAuth2Client,
    });

    res.status(200).json({
      message: "Event deleted successfully!",
      eventId: eventId,
    });
  } catch (err) {
    console.error("Error deleting event:", err.message);
    res.status(500).json({
      message: "Error deleting event",
      error: err.message,
    });
  }
};

