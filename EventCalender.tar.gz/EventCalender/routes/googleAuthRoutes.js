const express = require("express");
const { getAuthUrl, handleCallback , scheduleEvents, updateEvent, deleteEvent} = require("../controller/googleController");

const router = express.Router();

// Generate Google OAuth URL
router.get("/auth", getAuthUrl);

// Handle Google OAuth Callback
router.get("/redirect", handleCallback);

// schedule event
router.post("/schedule_events", scheduleEvents);

// update scheduled event
router.put("/update_event", updateEvent);

// delete scheduled event
router.delete("/delete_event", deleteEvent);



module.exports = router;
